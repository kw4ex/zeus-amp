export default class Kpa1500Panel extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.renderFramework();
    }

    connectedCallback() {
        // Automatically request current hardware dimensions from Zeus host window frame
        this.bindZeusDataStream();
        this.shadowRoot.getElementById('btn-connect').addEventListener('click', () => this.toggleConnect());
        this.shadowRoot.getElementById('btn-oper').addEventListener('click', () => this.toggleOperStby());
    }

    renderFramework() {
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: flex;
                    flex-direction: column;
                    padding: 10px;
                    box-sizing: border-box;
                    background: #1e1e1e;
                    color: #ffffff;
                    font-family: sans-serif;
                    height: 100%;
                    width: 100%;
                    min-width: 200px;
                }
                .section { margin-bottom: 12px; }
                label { display: block; font-size: 11px; color: #aaaaaa; margin-bottom: 4px; }
                input { width: 100%; box-sizing: border-box; padding: 6px; background: #333; border: 1px solid #555; color: #fff; border-radius: 4px; }
                button { width: 100%; padding: 10px; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; margin-top: 5px; }
                #btn-connect { background: #007acc; color: white; }
                #btn-oper { background: #444; color: white; height: 45px; font-size: 14px; }
                .status-container { display: flex; justify-content: space-between; font-size: 13px; font-weight: bold; padding: 6px 0; }
                #status { color: #ff3b30; }
                .meter-container { background: #222; border: 1px solid #444; height: 20px; border-radius: 4px; overflow: hidden; position: relative; }
                #meter-bar { width: 0%; height: 100%; background: #4cd964; transition: width 0.1s ease; }
                #meter-text { position: absolute; width: 100%; text-align: center; font-size: 11px; line-height: 20px; font-weight: bold; top: 0; }
            </style>
            
            <div class="section">
                <label>Amplifier Connection Matrix</label>
                <input type="text" id="amp-ip" value="192.168.1.150" placeholder="IP Address">
                <button id="btn-connect">Connect to Amplifier</button>
            </div>

            <div class="section status-container">
                <div>Link Status: <span id="status">DISCONNECTED</span></div>
                <div id="band-readout">Band: --m</div>
            </div>

            <div class="section">
                <label>Forward Power Output</label>
                <div class="meter-container">
                    <div id="meter-bar"></div>
                    <div id="meter-text">0 W / 1500W</div>
                </div>
            </div>

            <div class="section">
                <button id="btn-oper">STANDBY</button>
            </div>
        `;
    }

    bindZeusDataStream() {
        // Listens to telemetry callbacks passing up from the background C# engine pipeline
        window.Zeus.onPluginMessage("org.zeussdr.elecraft.kpa1500", (message) => {
            const data = JSON.parse(message);
            if (data.status) {
                const statusEl = this.shadowRoot.getElementById('status');
                statusEl.innerText = data.status.toUpperCase();
                statusEl.style.color = data.status === "connected" ? "#4cd964" : "#ff3b30";
                this.shadowRoot.getElementById('btn-connect').innerText = data.status === "connected" ? "Disconnect" : "Connect to Amplifier";
            }
            if (data.band) this.shadowRoot.getElementById('band-readout').innerText = `Band: ${data.band}m`;
            if (data.mode) {
                const operBtn = this.shadowRoot.getElementById('btn-oper');
                operBtn.innerText = data.mode.toUpperCase();
                operBtn.style.background = data.mode === "operate" ? "#ff3b30" : "#4cd964";
                operBtn.style.color = data.mode === "operate" ? "#ffffff" : "#000000";
            }
            if (typeof data.pwr !== 'undefined') {
                const percentage = Math.min((data.pwr / 1500) * 100, 100);
                const bar = this.shadowRoot.getElementById('meter-bar');
                bar.style.width = `${percentage}%`;
                bar.style.background = data.pwr > 1300 ? "#ff3b30" : "#4cd964";
                this.shadowRoot.getElementById('meter-text').innerText = `${data.pwr} W / 1500W`;
            }
        });
    }

    toggleConnect() {
        const ip = this.shadowRoot.getElementById('amp-ip').value;
        window.Zeus.sendToPluginBackend("org.zeussdr.elecraft.kpa1500", JSON.stringify({ action: "toggle_link", targetIp: ip }));
    }

    toggleOperStby() {
        window.Zeus.sendToPluginBackend("org.zeussdr.elecraft.kpa1500", JSON.stringify({ action: "toggle_mode" }));
    }
}
customElements.define('zeus-kpa1500-panel', Kpa1500Panel);
